
package com.quickart.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    private Integer id;
    private Integer productId;
    // other fields, getters, setters

    // Constructors, getters, setters
}
